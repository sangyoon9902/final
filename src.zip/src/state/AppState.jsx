import React, { createContext, useContext, useState } from 'react'


const Ctx = createContext(null)


export function AppProvider({children}){
const [profile, setProfile] = useState({ name:'', sex:'M', age:25, height:170, weight:65 })
const [selectedTest, setSelectedTest] = useState(null) // 'situp' | 'jump' | 'step' | 'reach'
const [session, setSession] = useState({
situp: { reps: 0, maxTorsoDeg: 0 },
jump: { reps: 0, avgAirMs: 0, maxAirMs: 0 },
step: { durationSec: 180, bpm: 96, compliance: 0 },
reach: { bestCm: 0, scalePxPerCm: 0, baselinePx: null }
})
const value = { profile, setProfile, selectedTest, setSelectedTest, session, setSession }
return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
export const useApp = () => useContext(Ctx)
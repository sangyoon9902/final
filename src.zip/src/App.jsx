import { Outlet, Link, useLocation } from 'react-router-dom'


export default function App(){
const loc = useLocation()
return (
<div style={{display:'grid',gridTemplateRows:'64px 1fr',height:'100%'}}>
<header style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 16px',borderBottom:'1px solid #1a2550'}}>
<strong>🏋️ AI Fitness</strong>
<nav style={{display:'flex',gap:12}}>
<Link to="/" className="btn">시작</Link>
<Link to="/profile" className="btn">개인정보</Link>
<Link to="/select" className="btn">종목선택</Link>
<Link to="/measure" className="btn">측정</Link>
<Link to="/results" className="btn">결과</Link>
<Link to="/gesture-test" className="btn">제스처테스트</Link>
</nav>
</header>
<main style={{padding:16}}>
<Outlet key={loc.key} />
</main>
</div>
)
}
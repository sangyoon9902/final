import { useNavigate } from "react-router-dom";
import { useApp } from "../state/AppState";

// Select.jsx — 3종목 전용: 윗몸말아올리기 / 스텝검사 / 앉아윗몸앞으로굽히기
export default function Select() {
  const nav = useNavigate();
  const { setSelectedTest } = useApp();

  const tests = [
    {
      id: "situp",
      title: "윗몸말아올리기",
      desc: "측면(약 70°)·엉덩이 높이, 상체~무릎 프레임 인",
      guide: "매트에 누워 무릎을 세운 자세에서 상체를 말아 올렸다가 내립니다.",
    },
    {
      id: "step",
      title: "스텝검사",
      desc: "정면 카메라, 허리~발목 보이게, 스텝박스 프레임 인",
      guide: "96bpm 메트로놈에 맞춰 3분간 스텝을 밟습니다.",
    },
    {
      id: "reach",
      title: "앉아윗몸앞으로굽히기(cm)",
      desc: "정측면(90°)·엉덩이 높이, 손끝과 기준대/눈금 보이게",
      guide: "다리를 펴고 앉아 손끝을 앞으로 뻗어 최대 거리(cm)를 측정합니다.",
    },
  ];

  const go = (id) => {
    setSelectedTest(id);
    nav("/measure");
  };

  return (
    <div className="card">
      <h2 style={{ marginTop: 0 }}>종목 선택</h2>
      <p className="muted">세 종목 중 하나를 선택해 측정을 진행하세요.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12 }}>
        {tests.map((t) => (
          <button key={t.id} className="card hover" style={{ textAlign: "left" }} onClick={() => go(t.id)}>
            <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 4 }}>{t.title}</div>
            <div className="muted" style={{ marginBottom: 6 }}>{t.desc}</div>
            <div style={{ fontSize: 13 }}>{t.guide}</div>
          </button>
        ))}
      </div>

      <div style={{ marginTop: 12 }}>
        <button className="btn" onClick={() => nav("/")}>뒤로</button>
      </div>
    </div>
  );
}

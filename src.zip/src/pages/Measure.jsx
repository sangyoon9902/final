import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "../state/AppState";
import { useNavigate } from "react-router-dom";

/* ──────────────────────────────── 공통 유틸 ──────────────────────────────── */
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const formatMMSS = (sec) =>
  `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(
    Math.floor(sec % 60)
  ).padStart(2, "0")}`;

function angleDeg(a, b, c) {
  const v1 = { x: a.x - b.x, y: a.y - b.y };
  const v2 = { x: c.x - b.x, y: c.y - b.y };
  const dot = v1.x * v2.x + v1.y * v2.y;
  const m1 = Math.hypot(v1.x, v1.y) || 1e-6;
  const m2 = Math.hypot(v2.x, v2.y) || 1e-6;
  const cos = clamp(dot / (m1 * m2), -1, 1);
  return (Math.acos(cos) * 180) / Math.PI;
}

const IDX = {
  L_SH: 11,
  R_SH: 12,
  L_EL: 13,
  R_EL: 14,
  L_WR: 15,
  R_WR: 16,
  L_HIP: 23,
  R_HIP: 24,
  L_KNEE: 25,
  R_KNEE: 26,
  L_ANK: 27,
  R_ANK: 28,
};

const VIS_TH = 0.6;
const SIT_SIDE_MIN = 5;

/* ─────────────── 프레이밍 각도 계산 (Yaw) ─────────────── */
function angleRequirement(test) {
  switch (test) {
    case "situp":
      return { min: 55, max: 85, label: "측면(약 70°)" };
    case "reach":
      return { min: 75, max: 95, label: "측면(약 90°)" };
    case "step":
      return { min: 0, max: 20, label: "정면(≤20°)" }; // step은 카메라 안 쓰지만 그대로 둠
    default:
      return { min: 0, max: 180, label: "" };
  }
}

function estimateYawDeg(lms) {
  const Ls = lms[IDX.L_SH],
    Rs = lms[IDX.R_SH],
    Lh = lms[IDX.L_HIP],
    Rh = lms[IDX.R_HIP];
  const useShoulder =
    Ls && Rs && (Ls.visibility ?? 0) + (Rs.visibility ?? 0) >= 0.8;

  const A = useShoulder ? Ls : Lh;
  const B = useShoulder ? Rs : Rh;
  if (!A || !B) return NaN;

  const dx = Math.abs((B.x ?? 0) - (A.x ?? 0));
  const dz = Math.abs((B.z ?? 0) - (A.z ?? 0)); // 정면≈0, 측면≈90
  return (Math.atan2(dz, Math.max(1e-6, dx)) * 180) / Math.PI;
}

function angleOKForTest(test, yaw) {
  const req = angleRequirement(test);
  return Number.isFinite(yaw) && yaw >= req.min && yaw <= req.max;
}

/* ─────────────── situp 한쪽면 가시성, 몸각도 ─────────────── */
function bestSideForSitup(lms) {
  const L = [
    IDX.L_SH,
    IDX.L_EL,
    IDX.L_WR,
    IDX.L_HIP,
    IDX.L_KNEE,
    IDX.L_ANK,
  ];
  const R = [
    IDX.R_SH,
    IDX.R_EL,
    IDX.R_WR,
    IDX.R_HIP,
    IDX.R_KNEE,
    IDX.R_ANK,
  ];

  const score = (arr) =>
    arr.reduce((c, i) => {
      const p = lms[i];
      if (!p) return c;
      const ok =
        (p.visibility ?? 0) >= VIS_TH &&
        p.x >= 0 &&
        p.x <= 1 &&
        p.y >= 0 &&
        p.y <= 1;
      return c + (ok ? 1 : 0);
    }, 0);

  const lc = score(L);
  const rc = score(R);
  const side = lc >= rc ? "L" : "R";
  const count = Math.max(lc, rc);

  const S =
    side === "L"
      ? { SH: IDX.L_SH, HIP: IDX.L_HIP, KNEE: IDX.L_KNEE }
      : { SH: IDX.R_SH, HIP: IDX.R_HIP, KNEE: IDX.R_KNEE };

  return { side, count, idx: S };
}

/* ─────────────── situp 반복 카운터 ─────────────── */
const situpPhase = { phase: "down", lastChange: 0 };
const angleBuf = [];

function smooth5(v) {
  if (!Number.isFinite(v)) return v;
  angleBuf.push(v);
  if (angleBuf.length > 5) angleBuf.shift();
  const s = [...angleBuf].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

function detectSitupAngle(angRaw, repsRef, setHud) {
  if (!Number.isFinite(angRaw)) return;
  const ang = smooth5(angRaw);

  const now = performance.now();
  const HOLD = 150;
  const UP = 70;
  const DOWN = 110;
  const prev = situpPhase.phase;

  if (prev === "down" && ang <= UP) {
    if (now - situpPhase.lastChange > HOLD) {
      situpPhase.phase = "up";
      situpPhase.lastChange = now;
    }
  } else if (prev === "up" && ang >= DOWN) {
    if (now - situpPhase.lastChange > HOLD) {
      situpPhase.phase = "down";
      situpPhase.lastChange = now;
      repsRef.current += 1;
    }
  }

  setHud((h) => ({
    ...h,
    reps: repsRef.current,
    status: `각도 ${Math.round(ang)}° (${situpPhase.phase})`,
  }));
}

/* ─────────────── 전굴(cm) 추정 ─────────────── */
function detectReach(lms, setHud, canvas) {
  const hip = {
    x: (lms[IDX.L_HIP].x + lms[IDX.R_HIP].x) / 2,
    y: (lms[IDX.L_HIP].y + lms[IDX.R_HIP].y) / 2,
  };
  const sh = {
    x: (lms[IDX.L_SH].x + lms[IDX.R_SH].x) / 2,
    y: (lms[IDX.L_SH].y + lms[IDX.R_SH].y) / 2,
  };
  const wr = {
    x: (lms[IDX.L_WR].x + lms[IDX.R_WR].x) / 2,
    y: (lms[IDX.L_WR].y + lms[IDX.R_WR].y) / 2,
  };

  const hipX = hip.x * canvas.width;
  const wristX = wr.x * canvas.width;
  const shX = sh.x * canvas.width;
  const hipY = hip.y * canvas.height;
  const shY = sh.y * canvas.height;

  const forwardPx = wristX - hipX;
  const torsoPx = Math.hypot(shX - hipX, shY - hipY) || 1;
  const cmPerPx = 30 / torsoPx; // 어깨-엉덩이 ~30cm 가정
  const best = Math.max(0, forwardPx * cmPerPx);

  setHud((h) => ({
    ...h,
    reps: parseFloat(best.toFixed(1)),
    status: `최대 전방 ${best.toFixed(1)} cm`,
  }));

  return best;
}

/* ──────────────────────────────── Pulsoid 연동 (step 테스트용) ─────────────────────────────── */

/*
Pulsoid access token (너 개인 토큰)
!!! 절대 깃헙/배포용 코드에 그대로 넣지 말고 개발용에서만 써 !!!
*/
const PULSOID_TOKEN = "23f9c9d7-66f3-4f58-a68f-505500ef6b15";

/*
Pulsoid에서 현재 심박을 0.5초마다 가져오는 hook.
enabled=true일 때만 계속 fetch한다.
*/
function usePulsoidBpm(token, enabled) {
  const [bpm, setBpm] = useState(null);

  useEffect(() => {
    if (!enabled) return;
    if (!token) return;

    let alive = true;
    const id = setInterval(async () => {
      try {
        const res = await fetch("http://localhost:3001/api/heart-rate");

        if (!res.ok) {
          // 토큰 에러나 아직 워치/Pulsoid 앱이 준비 안 된 상태일 수 있음
          return;
        }
        const data = await res.json();
        // Pulsoid 응답 형태에 맞춰 보기:
        // 문서 예시는 { "heart_rate": 86, "timestamp": 1234567890 }
        const newBpm =
          data.heart_rate ?? data.data?.heart_rate ?? null;

        if (alive) {
          setBpm(newBpm);
        }
      } catch (e) {
        console.error("Pulsoid fetch error", e);
      }
    }, 500); // 0.5초마다 한번씩

    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [token, enabled]);

  return bpm;
}

/* 스텝 테스트 상수들 (심폐지구력 프로토콜) */
const STEP_STEPPING_SEC = 180; // 3분 스텝
const STEP_RECOVERY_SEC = 60; // 1분 회복

function calcFitnessScore(recoveryBPM) {
  if (recoveryBPM == null) return null;
  if (recoveryBPM < 90) return { grade: 1, desc: "매우 우수" };
  if (recoveryBPM < 100) return { grade: 2, desc: "우수" };
  if (recoveryBPM < 110) return { grade: 3, desc: "보통" };
  if (recoveryBPM < 120) return { grade: 4, desc: "보통 이하" };
  if (recoveryBPM < 130) return { grade: 5, desc: "부족" };
  return { grade: 6, desc: "매우 부족" };
}

/* ──────────────────────────────── 컴포넌트 본체 ─────────────────────────────── */
export default function Measure() {
  const { selectedTest } = useApp(); // "step" | "situp" | "reach"
  const nav = useNavigate();

  /* situp / reach용 카메라 상태 */
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const [hud, setHud] = useState({ fps: 0, reps: 0, status: "대기" });
  const [phase, setPhase] = useState("guide"); // guide → countdown → running → finished
  const [count, setCount] = useState(5);
  const [subtitle, setSubtitle] = useState("프레이밍을 맞춰주세요.");
  const [error, setError] = useState("");

  const [yawDeg, setYawDeg] = useState(NaN);
  const [angleOK, setAngleOK] = useState(false);
  const [sideCount, setSideCount] = useState(0);
  const [sitAngle, setSitAngle] = useState(NaN);

  const situpAudioRef = useRef(null);

  const phaseRef = useRef(phase);
  useEffect(() => {
    phaseRef.current = phase;
  }, [phase]);

  const testRef = useRef(selectedTest);
  useEffect(() => {
    testRef.current = selectedTest;
  }, [selectedTest]);

  const repsRef = useRef(0);
  useEffect(() => {
    repsRef.current = hud.reps;
  }, [hud.reps]);

  const labelMap = useMemo(
    () => ({
      situp: "윗몸말아올리기",
      step: "스텝검사",
      reach: "앉아윗몸앞으로굽히기(cm)",
    }),
    []
  );

  /* ── Pulsoid 기반 step 상태들 ───────────────── */
  // Pulsoid 연결 여부 (사용자가 "Pulsoid 연결" 버튼 누르면 true로 전환)
  const [pulsoidConnected, setPulsoidConnected] = useState(false);

  // Pulsoid에서 받은 실시간 bpm (pulsoidConnected === true일 때만 가져옴)
  const pulsoidBpm = usePulsoidBpm(PULSOID_TOKEN, pulsoidConnected);

  // UI에서 쓸 이름 통일: hrBpm
  const hrBpm = pulsoidBpm;

  const [stepPhase, setStepPhase] = useState("idle"); // idle | stepping | recovery | done
  const stepPhaseRef = useRef(stepPhase);
  useEffect(() => {
    stepPhaseRef.current = stepPhase;
  }, [stepPhase]);

  // 타이머
  const [stepTimer, setStepTimer] = useState(STEP_STEPPING_SEC);
  const [recoveryTimer, setRecoveryTimer] = useState(STEP_RECOVERY_SEC);

  // 회복 구간 평균용
  const recoveryCollectRef = useRef([]);
  const [recoveryAvg, setRecoveryAvg] = useState(null);
  const [stepScore, setStepScore] = useState(null);

  // 헬프 모달
  const [showHelp, setShowHelp] = useState(false);

  /* situp/reach 전용 오디오 */
  useEffect(() => {
    const el = new Audio("/audio/situp-cue.mp3");
    el.preload = "auto";
    situpAudioRef.current = el;
    return () => {
      try {
        el.pause();
      } catch {}
    };
  }, []);

  /* situp / reach Pose 초기화 */
  useEffect(() => {
    if (selectedTest === "step") return; // step은 카메라 안 씀

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const pose = new window.Pose({
      locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${f}`,
    });
    pose.setOptions({
      modelComplexity: 1,
      smoothLandmarks: true,
      enableSegmentation: false,
      minDetectionConfidence: 0.5,
      minTrackingConfidence: 0.5,
    });

    let lastTs = performance.now();
    pose.onResults((res) => {
      const now = performance.now();
      const fps = Math.round(1000 / Math.max(16, now - lastTs));
      lastTs = now;
      setHud((h) => ({ ...h, fps }));

      // 카메라 프레임 그리기
      const img = res.image;
      if (img) {
        if (canvas.width !== img.width || canvas.height !== img.height) {
          canvas.width = img.width;
          canvas.height = img.height;
        }
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      }

      const lms = res.poseLandmarks;
      if (!lms || !lms.length) return;

      // 프레이밍 각도
      const yaw = estimateYawDeg(lms);
      setYawDeg(yaw);
      const okYaw = angleOKForTest(testRef.current, yaw);
      setAngleOK(okYaw);

      // 스켈레톤 디버그 표시
      if (window.drawConnectors && window.POSE_CONNECTIONS) {
        window.drawConnectors(ctx, lms, window.POSE_CONNECTIONS, {
          color: "#8ab4ff",
          lineWidth: 3,
        });
        window.drawLandmarks(ctx, lms, {
          color: "#fffb91",
          radius: 3,
        });
      }

      // HUD에 프레이밍 info
      drawFramingHUD(ctx, testRef.current, yaw, okYaw);

      // situp 동작
      if (testRef.current === "situp") {
        const { count: c, idx } = bestSideForSitup(lms);
        setSideCount(c);

        const SH = lms[idx.SH],
          HIP = lms[idx.HIP],
          KNEE = lms[idx.KNEE];
        if (SH && HIP && KNEE) {
          const ang = angleDeg(SH, HIP, KNEE);
          setSitAngle(ang);

          if (phaseRef.current === "running") {
            detectSitupAngle(ang, repsRef, setHud);
          }
        } else {
          setSitAngle(NaN);
        }
      }

      // reach 동작
      if (testRef.current === "reach" && phaseRef.current === "running") {
        detectReach(lms, setHud, canvas);
      }
    });

    const camera = new window.Camera(video, {
      onFrame: async () => {
        await pose.send({ image: video });
      },
      width: 1280,
      height: 720,
    });

    video.playsInline = true;
    video.muted = true;
    video.autoplay = true;

    camera
      .start()
      .catch((e) => {
        console.error(e);
        setError("카메라 시작 실패: HTTPS/권한/브라우저를 확인하세요.");
      });

    return () => {
      try {
        camera.stop();
      } catch {}
      try {
        pose.close();
      } catch {}
    };
  }, [selectedTest]);

  /* situp/reach: guide → countdown 조건 */
  useEffect(() => {
    if (selectedTest === "step") return;
    if (phase !== "guide") return;

    if (selectedTest === "situp") {
      if (sideCount >= SIT_SIDE_MIN && angleOK) {
        const t = setTimeout(() => {
          setPhase("countdown");
          setCount(5);
          angleBuf.length = 0;
        }, 600);
        return () => clearTimeout(t);
      }
    } else if (selectedTest === "reach") {
      if (angleOK) {
        const t = setTimeout(() => {
          setPhase("countdown");
          setCount(5);
        }, 600);
        return () => clearTimeout(t);
      }
    }
  }, [phase, selectedTest, sideCount, angleOK]);

  /* situp/reach: countdown → running */
  useEffect(() => {
    if (selectedTest === "step") return;
    if (phase !== "countdown") return;

    const timer = setInterval(() => {
      setCount((c) => {
        if (c <= 1) {
          clearInterval(timer);
          setPhase("running");

          if (selectedTest === "situp" && situpAudioRef.current) {
            try {
              situpAudioRef.current.currentTime = 0;
              situpAudioRef.current.play();
            } catch {}
          }
          return 0;
        }
        return c - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [phase, selectedTest]);

  /* situp/reach: subtitle 업데이트 */
  useEffect(() => {
    if (selectedTest === "step") return; // step은 별도 안내

    if (phase === "guide") {
      const req = angleRequirement(selectedTest);
      const yawTxt = Number.isFinite(yawDeg)
        ? `${Math.round(yawDeg)}°`
        : "—";

      if (selectedTest === "situp") {
        const angTxt = Number.isFinite(sitAngle)
          ? `${Math.round(sitAngle)}°`
          : "—";
        setSubtitle(
          `${angleOK ? "🟢" : "🔴"} 프레이밍 ${yawTxt} (목표 ${
            req.min
          }–${req.max}) · 측면 가시 ${sideCount}/6 · 몸각도 ${angTxt}`
        );
      } else if (selectedTest === "reach") {
        setSubtitle(
          `${angleOK ? "🟢" : "🔴"} 프레이밍 ${yawTxt} (목표 ${
            req.min
          }–${req.max})`
        );
      } else {
        setSubtitle(
          `${angleOK ? "🟢" : "🔴"} 프레이밍 ${yawTxt}`
        );
      }
    } else if (phase === "countdown") {
      setSubtitle(`측정을 준비하세요. ${count}초 후 시작`);
    } else if (phase === "running") {
      setSubtitle("측정 중입니다.");
    } else if (phase === "finished") {
      setSubtitle("측정 종료. 수고하셨습니다!");
    }
  }, [phase, selectedTest, yawDeg, angleOK, sideCount, sitAngle, count]);

  /* step: 3분 스텝 타이머 */
  useEffect(() => {
    if (selectedTest !== "step") return;
    if (stepPhase !== "stepping") return;

    if (stepTimer <= 0) {
      // 3분 끝나면 회복 구간 시작
      setStepPhase("recovery");
      setRecoveryTimer(STEP_RECOVERY_SEC);
      return;
    }

    const id = setTimeout(() => {
      setStepTimer((t) => t - 1);
    }, 1000);

    return () => clearTimeout(id);
  }, [selectedTest, stepPhase, stepTimer]);

  /* step: 회복 타이머 (1분) + 회복 중 bpm 수집 */
  useEffect(() => {
    if (selectedTest !== "step") return;
    if (stepPhase !== "recovery") return;

    if (recoveryTimer <= 0) {
      // 평균 계산
      const arr = recoveryCollectRef.current
        .map((d) => d.bpm)
        .filter((x) => Number.isFinite(x));
      const avg = arr.length
        ? arr.reduce((a, b) => a + b, 0) / arr.length
        : null;

      setRecoveryAvg(avg);
      setStepScore(calcFitnessScore(avg));
      setStepPhase("done");
      return;
    }

    // 현재 bpm 기록
    if (hrBpm != null) {
      recoveryCollectRef.current.push({
        t: performance.now(),
        bpm: hrBpm,
      });
    }

    const id = setTimeout(() => {
      setRecoveryTimer((t) => t - 1);
    }, 1000);

    return () => clearTimeout(id);
  }, [selectedTest, stepPhase, recoveryTimer, hrBpm]);

  /* step: 버튼 핸들러들 */
  function handleConnectPulsoid() {
    // 지금은 그냥 "연결 시작" 토글 느낌으로 사용
    // 실제 서비스에선 이 버튼에서 Pulsoid OAuth를 붙여서 토큰 받아오면 됨
    setPulsoidConnected(true);
  }

  function handleStartStep() {
    // 초기화 후 스텝 세션 시작
    recoveryCollectRef.current = [];
    setRecoveryAvg(null);
    setStepScore(null);
    setStepTimer(STEP_STEPPING_SEC);
    setRecoveryTimer(STEP_RECOVERY_SEC);
    setStepPhase("stepping");
  }

  function handleResetAll() {
    // situp/reach 초기화
    situpPhase.phase = "down";
    situpPhase.lastChange = 0;
    angleBuf.length = 0;

    setHud({ fps: 0, reps: 0, status: "대기" });
    setYawDeg(NaN);
    setAngleOK(false);
    setSideCount(0);
    setSitAngle(NaN);

    setPhase("guide");
    setSubtitle("프레이밍을 맞춰주세요.");
    setCount(5);

    // step 초기화
    setPulsoidConnected(false);
    recoveryCollectRef.current = [];
    setRecoveryAvg(null);
    setStepScore(null);
    setStepTimer(STEP_STEPPING_SEC);
    setRecoveryTimer(STEP_RECOVERY_SEC);
    setStepPhase("idle");
    setShowHelp(false);
  }

  /* situp/reach HUD용 */
  function drawFramingHUD(ctx, test, yaw, ok) {
    const { min, max, label } = angleRequirement(test);
    const boxW = 260,
      boxH = 52,
      x = ctx.canvas.width - boxW - 12,
      y = 12;

    ctx.fillStyle = "rgba(20,40,90,.7)";
    ctx.fillRect(x, y, boxW, boxH);

    ctx.strokeStyle = ok ? "#20d6a5" : "#ff6b6b";
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 0.5, y + 0.5, boxW - 1, boxH - 1);

    ctx.fillStyle = "#e8ecff";
    ctx.font = "12px system-ui";
    const yawTxt = Number.isFinite(yaw) ? `${Math.round(yaw)}°` : "—";
    ctx.fillText(`프레이밍 각도(Yaw): ${yawTxt}`, x + 10, y + 20);
    ctx.fillText(
      `목표: ${min}–${max}° · ${label}`,
      x + 10,
      y + 38
    );
  }

  /* 공통 스타일 */
  const pillStyle = {
    background: "#1a1a2a",
    border: "1px solid #444",
    borderRadius: "999px",
    padding: "6px 10px",
    fontSize: "12px",
    lineHeight: 1.3,
  };

  const btnStyle = (bg) => ({
    background: bg,
    color: "#fff",
    border: "none",
    borderRadius: "10px",
    padding: "10px 14px",
    fontSize: "14px",
    lineHeight: 1.3,
    fontWeight: 600,
    cursor: "pointer",
    minWidth: "120px",
  });

  /* ─────────────── 렌더: step 모드 ─────────────── */
  if (selectedTest === "step") {
    return (
      <div
        style={{
          padding: "16px",
          color: "#fff",
          backgroundColor: "#000",
          position: "relative",
          minHeight: "100vh",
        }}
      >
        {/* 도움말 모달 */}
        {showHelp && (
          <>
            <div
              style={{
                position: "fixed",
                inset: 0,
                backgroundColor: "rgba(0,0,0,0.6)",
                zIndex: 999,
              }}
              onClick={() => setShowHelp(false)}
            />
            <div
              style={{
                position: "fixed",
                zIndex: 1000,
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                background: "#1a1a2a",
                border: "1px solid #444",
                borderRadius: "16px",
                boxShadow: "0 20px 60px rgba(0,0,0,0.8)",
                width: "90%",
                maxWidth: "360px",
                padding: "20px",
                fontSize: "14px",
                lineHeight: 1.5,
                color: "#fff",
              }}
            >
              <div
                style={{
                  fontSize: "16px",
                  fontWeight: 600,
                  marginBottom: "12px",
                  textAlign: "center",
                }}
              >
                Pulsoid 연결 방법
              </div>

              <ol
                style={{
                  margin: 0,
                  paddingLeft: "20px",
                  display: "grid",
                  rowGap: "10px",
                  color: "#ddd",
                }}
              >
                <li>
                  갤럭시 워치(또는 착용한 기기)에서 Pulsoid 앱을 실행하고
                  심박 측정을 켜세요.
                </li>
                <li>
                  Pulsoid 계정에 로그인된 상태에서 심박 BPM이
                  올라오는지 워치/폰에서 확인하세요.
                </li>
                <li>
                  이 화면에서 &quot;Pulsoid 연결&quot; 버튼을 누르면
                  실시간 심박을 불러오기 시작합니다.
                </li>
                <li>
                  실시간 심박수가 보이면 &quot;스텝검사 시작 (3분)&quot;을
                  눌러주세요. 3분 끝나면 자동으로 회복 1분을 측정합니다.
                </li>
              </ol>

              <div
                style={{
                  marginTop: "20px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <button
                  style={btnStyle("#28a")}
                  onClick={() => setShowHelp(false)}
                >
                  이해했어요
                </button>
              </div>
            </div>
          </>
        )}

        {/* 상단 안내 카드 */}
        <div
          style={{
            background: "#1118",
            padding: 8,
            borderRadius: 8,
            textAlign: "center",
            marginBottom: 8,
            lineHeight: 1.4,
          }}
        >
          {stepPhase === "idle" && (
            <>
              <div
                style={{
                  fontWeight: 600,
                  fontSize: "14px",
                }}
              >
                Pulsoid로 심박을 받아와서 스텝검사를 진행합니다.
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "#ccc",
                }}
              >
                워치에서 Pulsoid 앱을 켜고 심박이 올라오는 걸 확인한 뒤
                아래 &quot;Pulsoid 연결&quot;을 눌러주세요.
                <br />
                실시간 BPM이 보이면 3분 스텝검사를 시작할 수 있어요.
              </div>
            </>
          )}

          {stepPhase === "stepping" && (
            <>
              <div
                style={{
                  fontWeight: 600,
                  fontSize: "14px",
                }}
              >
                3분 동안 일정한 리듬으로 스텝박스를 올라갔다 내려오세요.
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "#ccc",
                }}
              >
                타이머가 0이 되면 바로 앉아서 쉬세요.
                <br />
                회복 심박을 1분 동안 자동으로 기록합니다.
              </div>
            </>
          )}

          {stepPhase === "recovery" && (
            <>
              <div
                style={{
                  fontWeight: 600,
                  fontSize: "14px",
                }}
              >
                회복 중입니다. 편하게 앉아서 쉬세요.
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "#ccc",
                }}
              >
                심박수를 자동으로 기록하는 중입니다…
              </div>
            </>
          )}

          {stepPhase === "done" && (
            <>
              <div
                style={{
                  fontWeight: 600,
                  fontSize: "14px",
                }}
              >
                측정 완료!
              </div>
              <div
                style={{
                  fontSize: "12px",
                  color: "#ccc",
                }}
              >
                아래 결과를 확인하세요.
              </div>
            </>
          )}
        </div>

        {/* HUD */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "12px",
            marginBottom: "12px",
          }}
        >
          <div className="pill" style={pillStyle}>
            현재 심박수 {hrBpm ? `${hrBpm} bpm` : "-- bpm"}
          </div>

          {stepPhase === "stepping" && (
            <div className="pill" style={pillStyle}>
              스텝 남은 시간 {formatMMSS(stepTimer)}
            </div>
          )}

          {stepPhase === "recovery" && (
            <div className="pill" style={pillStyle}>
              회복 남은 시간 {formatMMSS(recoveryTimer)}
            </div>
          )}

          {stepPhase === "done" && (
            <>
              <div className="pill" style={pillStyle}>
                회복 평균{" "}
                {recoveryAvg ? recoveryAvg.toFixed(1) + " bpm" : "--"}
              </div>
              {stepScore && (
                <div className="pill" style={pillStyle}>
                  예측 등급 {stepScore.grade}등급 ({stepScore.desc})
                </div>
              )}
            </>
          )}
        </div>

        {/* 버튼들 */}
        <div
          style={{
            marginTop: 12,
            display: "flex",
            flexWrap: "wrap",
            gap: "8px",
          }}
        >
          {stepPhase === "idle" && (
            <>
              {/* 도움말 */}
              <button
                className="btn"
                style={btnStyle("#555")}
                onClick={() => setShowHelp(true)}
              >
                연결 방법
              </button>

              {/* Pulsoid 연결 */}
              <button
                className="btn"
                style={btnStyle(pulsoidConnected ? "#2d6" : "#555")}
                onClick={handleConnectPulsoid}
              >
                {pulsoidConnected ? "Pulsoid 연결됨 ✅" : "Pulsoid 연결"}
              </button>

              {/* 스텝검사 시작 */}
              <button
                className="btn"
                style={btnStyle(pulsoidConnected ? "#28a" : "#444")}
                disabled={!pulsoidConnected}
                onClick={handleStartStep}
              >
                스텝검사 시작 (3분)
              </button>
            </>
          )}

          {stepPhase === "stepping" && (
            <button
              className="btn"
              style={btnStyle("#a33")}
              onClick={handleResetAll}
            >
              중단 / 리셋
            </button>
          )}

          {stepPhase === "recovery" && (
            <button
              className="btn"
              style={btnStyle("#a33")}
              onClick={handleResetAll}
            >
              중단 / 리셋
            </button>
          )}

          {stepPhase === "done" && (
            <>
              <button
                className="btn"
                style={btnStyle("#28a")}
                onClick={() => nav("/results")}
              >
                결과 보기 / 저장
              </button>

              <button
                className="btn"
                style={btnStyle("#555")}
                onClick={handleResetAll}
              >
                다시 측정
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  /* ─────────────── 렌더: situp / reach 모드 ─────────────── */
  return (
    <div
      style={{
        padding: "16px",
        color: "#fff",
        backgroundColor: "#000",
      }}
    >
      {error && (
        <div
          style={{
            background: "#3a1120",
            border: "1px solid #a23",
            padding: 8,
            borderRadius: 8,
            marginBottom: 8,
          }}
        >
          ⚠️ {error}
        </div>
      )}

      <div
        style={{
          background: "#1118",
          padding: 8,
          borderRadius: 8,
          textAlign: "center",
          marginBottom: 8,
        }}
      >
        {phase === "countdown" ? `곧 시작: ${count}` : subtitle}
      </div>

      <div
        className="camwrap"
        style={{
          position: "relative",
        }}
      >
        <video
          ref={videoRef}
          playsInline
          autoPlay
          muted
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
          }}
        />
        <canvas
          ref={canvasRef}
          width={1280}
          height={720}
          style={{
            width: "100%",
            height: "auto",
          }}
        />
      </div>

      <div
        style={{
          marginTop: 12,
          display: "flex",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <span className="pill" style={pillStyle}>
          FPS {hud.fps}
        </span>
        <span className="pill" style={pillStyle}>
          상태 {hud.status}
        </span>
        <span className="pill" style={pillStyle}>
          Yaw {Number.isFinite(yawDeg) ? Math.round(yawDeg) : "—"}°{" "}
          {angleOK ? "🟢" : "🔴"}
        </span>

        {selectedTest === "situp" && (
          <>
            <span className="pill" style={pillStyle}>
              측면 가시 {sideCount}/6
            </span>
            <span className="pill" style={pillStyle}>
              몸각도{" "}
              {Number.isFinite(sitAngle)
                ? Math.round(sitAngle)
                : "—"}
              °
            </span>
            <span className="pill" style={pillStyle}>
              횟수 {hud.reps}
            </span>
          </>
        )}

        {selectedTest === "reach" && (
          <span className="pill" style={pillStyle}>
            최대{" "}
            {typeof hud.reps === "number"
              ? hud.reps.toFixed(1)
              : hud.reps}{" "}
            cm
          </span>
        )}
      </div>

      <div
        style={{
          marginTop: 12,
          display: "flex",
          gap: "8px",
          flexWrap: "wrap",
        }}
      >
        <button
          className="btn"
          style={btnStyle("#28a")}
          onClick={() => nav("/results")}
        >
          결과 보기
        </button>

        <button
          className="btn"
          style={btnStyle("#555")}
          onClick={handleResetAll}
        >
          리셋
        </button>
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";

export default function GestureTest() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // HUD + 순서 진행 상태
  const [hud, setHud] = useState({ fps: 0, stableMs: 0, status: "대기", number: 0 });
  const [expected, setExpected] = useState(1);      // 지금 기다리는 숫자 (1→5)
  const [doneCount, setDoneCount] = useState(0);    // 몇 개 완료했는지
  const [message, setMessage] = useState("");       // “완성했습니다” 등

  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    // ✅ CDN 전역: new window.Hands
    // @ts-ignore
    const hands = new window.Hands({
      locateFile: (f) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`,
    });
    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 1,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.6,
    });

    // 안정화 파라미터
    const N = 8;                   // 최근 N프레임 다수결
    const HOLD = 700;              // 동일 값 유지 ms
    const history = [];
    let pending = null, since = 0, lastStable = null;
    let lastTs = performance.now();

    // 제스처 확정시 순서 진행
    const onConfirm = (n) => {
      setHud((h) => ({ ...h, number: n, status: "확정" }));

      if (n === expected) {
        const next = expected + 1;
        setDoneCount((c) => c + 1);
        if (next > 5) {
          setMessage("완성했습니다 🎉");
          // 필요하면 자동 리셋
          // setTimeout(() => { setExpected(1); setDoneCount(0); setMessage(""); }, 1500);
        } else {
          setExpected(next);
          setMessage(""); // 진행 중이면 메시지 비움
        }
      } else if (n > 0) {
        // 틀린 숫자면 힌트만
        setMessage(`다음은 ${expected} 입니다.`);
      }
    };

    // @ts-ignore
    hands.onResults((res) => {
      const now = performance.now();
      const fps = (1000 / (now - lastTs)).toFixed(0);
      lastTs = now;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (res.image) ctx.drawImage(res.image, 0, 0, canvas.width, canvas.height);

      let n = 0;
      if (res.multiHandLandmarks?.length) {
        const lms = res.multiHandLandmarks[0];
        const info = res.multiHandedness?.[0];

        // draw
        // @ts-ignore
        window.drawConnectors(ctx, lms, window.HAND_CONNECTIONS, { color: "#8ab4ff", lineWidth: 3 });
        // @ts-ignore
        window.drawLandmarks(ctx, lms, { color: "#e8ff87", radius: 3 });

        const hand = info?.label || "Right";
        n = countFingers(lms, hand);

        // 다수결 + 홀드 안정화
        history.push(n);
        if (history.length > N) history.shift();
        const freq = [0, 0, 0, 0, 0, 0];
        history.forEach((v) => (freq[v] = (freq[v] || 0) + 1));
        const stable = freq.indexOf(Math.max(...freq));

        if (pending === null || pending !== stable) {
          pending = stable;
          since = now;
          setHud((h) => ({ ...h, status: "안정화 중" }));
        } else {
          const hold = now - since;
          setHud((h) => ({ ...h, stableMs: hold }));
          if (hold > HOLD && lastStable !== stable) {
            lastStable = stable;
            onConfirm(stable);
          }
        }
      } else {
        pending = null; lastStable = null;
        setHud((h) => ({ ...h, status: "손 없음", stableMs: 0, number: 0 }));
      }

      setHud((h) => ({ ...h, fps }));
      drawOverlay(ctx, canvas, hud.number || n, expected, doneCount, message);
    });

    // @ts-ignore
    const camera = new window.Camera(video, {
      width: 640, height: 480,
      onFrame: async () => { await hands.send({ image: video }); },
    });
    camera.start().catch((e) => {
      setHud((h) => ({ ...h, status: "카메라 오류: " + e?.message }));
    });

    return () => { try { camera.stop(); } catch {} };
  }, [expected, doneCount, message]); // 진행상태가 바뀌면 오버레이 갱신

  return (
    <div className="card">
      <h2 style={{ marginTop: 0 }}>손가락 제스처 구분 테스트</h2>
      <p className="muted">손가락을 1→2→3→4→5 순서대로 확정하면 완료됩니다.</p>

      <div className="muted" style={{ marginBottom: 6 }}>
        FPS {hud.fps} · 안정화 {Math.round(hud.stableMs)}ms · {hud.status}
      </div>

      <div style={{ position: "relative", borderRadius: 12, overflow: "hidden" }}>
        <video
          ref={videoRef}
          playsInline
          muted
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
        />
        <canvas ref={canvasRef} width={640} height={480} style={{ width: "100%", height: "auto" }} />
      </div>

      <Progress expected={expected} doneCount={doneCount} />
      {message && <div className="pill" style={{ marginTop: 8 }}>{message}</div>}
    </div>
  );
}

/* ---------- helper UI ---------- */
function Progress({ expected, doneCount }) {
  const items = [1, 2, 3, 4, 5];
  return (
    <div style={{ marginTop: 10, display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
      {items.map((n) => {
        const done = n <= doneCount;
        const isNext = n === expected;
        const bg = done ? "#1db954" : isNext ? "#3b82f6" : "#203067";
        const color = "#fff";
        return (
          <div key={n} style={{
            minWidth: 36, textAlign: "center", padding: "6px 10px",
            borderRadius: 999, background: bg, color, fontWeight: 700
          }}>
            {n}
          </div>
        );
      })}
    </div>
  );
}

/* ---------- drawing overlay ---------- */
function drawOverlay(ctx, canvas, currentNumber, expected, doneCount, message) {
  // 큰 숫자 오버레이(현재 인식값)
  ctx.save();
  ctx.font = "bold 72px system-ui";
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.fillRect(12, canvas.height - 100, 120, 88);
  ctx.fillStyle = "#e8ecff";
  ctx.fillText(String(currentNumber || "✋"), 32, canvas.height - 30);

  // 진행 상태 텍스트
  ctx.font = "16px system-ui";
  ctx.fillStyle = "#e8ecff";
  ctx.fillText(`다음 숫자: ${expected}`, 150, canvas.height - 60);
  if (doneCount > 0) ctx.fillText(`완료: ${doneCount}/5`, 150, canvas.height - 30);

  // 완료 메시지
  if (message) {
    ctx.font = "bold 28px system-ui";
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(canvas.width - 290, 16, 270, 44);
    ctx.fillStyle = "#b7ffb7";
    ctx.fillText(message, canvas.width - 280, 46);
  }
  ctx.restore();
}

/* ---------- finger utils ---------- */
function isFingerOpen(lms, tip, pip) { return lms[tip].y < lms[pip].y; }
function isThumbOpen(lms, hand) {
  const wrist = lms[0], tip = lms[4];
  return hand === "Right" ? tip.x > wrist.x + 0.03 : tip.x < wrist.x - 0.03;
}
function countFingers(lms, hand) {
  let c = 0;
  if (isThumbOpen(lms, hand)) c++;
  if (isFingerOpen(lms, 8, 6)) c++;
  if (isFingerOpen(lms, 12, 10)) c++;
  if (isFingerOpen(lms, 16, 14)) c++;
  if (isFingerOpen(lms, 20, 18)) c++;
  return c;
}

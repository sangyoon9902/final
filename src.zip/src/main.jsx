// src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

import App from './App';
import Start from './pages/Start';
import Profile from './pages/Profile';
import Select from './pages/Select';
import Measure from './pages/Measure';
import Results from './pages/Results';
import GestureTest from './pages/GestureTest';

// ✅ 설문 페이지 4단계 (파일이 이미 있다고 가정)
import Survey1 from './pages/Survey1';
import Survey2 from './pages/Survey2';
import Survey3 from './pages/Survey3';
import Survey4 from './pages/Survey4';

import { AppProvider } from './state/AppState';

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      // 홈/시작
      { index: true, element: <Start /> },

      // 프로필/선택/측정/결과/제스처 테스트
      { path: 'profile', element: <Profile /> },
      { path: 'select', element: <Select /> },
      { path: 'measure', element: <Measure /> },
      { path: 'results', element: <Results /> },
      { path: 'gesture-test', element: <GestureTest /> },

      // ✅ 설문 4단계
      { path: 'survey1', element: <Survey1 /> },
      { path: 'survey2', element: <Survey2 /> },
      { path: 'survey3', element: <Survey3 /> },
      { path: 'survey4', element: <Survey4 /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AppProvider>
      <RouterProvider router={router} />
    </AppProvider>
  </React.StrictMode>
);

import { useApp } from "../state/AppState";
import { useNavigate } from "react-router-dom";

export default function Results() {
  const { profile, session } = useApp();
  const nav = useNavigate();

  const grade = (type, val) => {
    if (type === "situp") return val >= 40 ? 1 : val >= 30 ? 2 : val >= 20 ? 3 : val >= 10 ? 4 : val > 0 ? 5 : 6;
    if (type === "jump") return val >= 50 ? 1 : val >= 40 ? 2 : val >= 30 ? 3 : val >= 20 ? 4 : val > 0 ? 5 : 6;
    if (type === "step") return val >= 0.95 ? 1 : val >= 0.9 ? 2 : val >= 0.8 ? 3 : val >= 0.7 ? 4 : val > 0.6 ? 5 : 6;
    if (type === "reach") return val >= 15 ? 1 : val >= 10 ? 2 : val >= 5 ? 3 : val >= 0 ? 4 : 6;
    return 6;
  };

  const gSit = grade("situp", session.situp.reps);
  const gJmp = grade("jump", session.jump.reps);
  const gStp = grade("step", session.step.compliance);
  const gRch = grade("reach", session.reach.bestCm);

  return (
    <div className="grid grid-2">
      <div className="card">
        <h2 style={{ marginTop: 0 }}>운동 결과</h2>
        <div className="muted">
          {profile.name || "사용자"} · {profile.sex === "M" ? "남" : "여"} · {profile.age}세
        </div>
        <ul>
          <li>윗몸일으키기: <b>{session.situp.reps}회</b> (등급 {gSit})</li>
          <li>반복점프: <b>{session.jump.reps}회</b> / 평균 체공 {Math.round(session.jump.avgAirMs)}ms (등급 {gJmp})</li>
          <li>스텝검사: 준수율 <b>{(session.step.compliance * 100).toFixed(0)}%</b> (등급 {gStp})</li>
          <li>앉아굽히기: <b>{session.reach.bestCm}cm</b> (등급 {gRch})</li>
        </ul>
        <div style={{ marginTop: 12 }}>
          <button className="btn" onClick={() => nav("/select")}>다시 측정하기</button>
        </div>
      </div>

      <div className="card">
        <h3 style={{ marginTop: 0 }}>운동처방 (데모)</h3>
        <p className="muted">국민체력100 기준 연동 예정. 아래는 예시 처방입니다.</p>
        <ul>
          <li>코어(플랭크/데드버그) 주 3회, 10~15분</li>
          <li>하체 파워(스쿼트 점프/반동 최소화) 주 2회, 3세트×10회</li>
          <li>유산소(스텝/계단) 주 3회, 20~30분</li>
          <li>유연성(햄스트링/둔근 스트레칭) 매일 10분</li>
        </ul>
      </div>
    </div>
  );
}

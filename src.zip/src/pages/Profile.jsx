import { useApp } from '../state/AppState'
import { useNavigate } from 'react-router-dom'


export default function Profile(){
const nav = useNavigate()
const { profile, setProfile } = useApp()
const up = (k,v) => setProfile({...profile, [k]:v})
return (
<div className="card">
<h2 style={{marginTop:0}}>개인정보 입력</h2>
<div className="grid" style={{gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:12}}>
<label>이름<br/><input value={profile.name} onChange={e=>up('name',e.target.value)} /></label>
<label>성별<br/>
<select value={profile.sex} onChange={e=>up('sex',e.target.value)}>
<option value="M">남</option>
<option value="F">여</option>
</select>
</label>
<label>나이<br/><input type="number" value={profile.age} onChange={e=>up('age',Number(e.target.value))} /></label>
<label>키(cm)<br/><input type="number" value={profile.height} onChange={e=>up('height',Number(e.target.value))} /></label>
<label>몸무게(kg)<br/><input type="number" value={profile.weight} onChange={e=>up('weight',Number(e.target.value))} /></label>
</div>
<div style={{marginTop:12,display:'flex',gap:8}}>
<button className="btn" onClick={()=>nav('/select')}>다음 → 종목 선택</button>
</div>
<p className="muted" style={{marginTop:12}}>입력값은 로컬 상태에만 저장됩니다.</p>
</div>
)
}